libreoffice-flat-icons
======================

Modded Icons for libreoffice 4.1.X
